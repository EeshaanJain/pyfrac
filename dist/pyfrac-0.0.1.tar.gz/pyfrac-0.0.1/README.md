# pyfrac
A python library to work with Fractions